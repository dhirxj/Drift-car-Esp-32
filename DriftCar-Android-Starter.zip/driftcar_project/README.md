# DriftCar ESP32 — Android controller starter

A landscape Android remote-control app for an ESP32-powered drift car.

## App controls
- Hold Forward / Reverse / Left / Right; releasing sends `stop`.
- Steering slider sends `steer_0` through `steer_180`.
- Headlight and DJ-light switches send on/off commands.
- Hold Horn sends `horn_on`; release sends `horn_off`.
- ESP32 IP is editable; default is `192.168.4.1`.

## Required ESP32 interface
The phone connects to the ESP32 Wi-Fi network and sends HTTP GET requests to:

`http://ESP32_IP/cmd?value=COMMAND`

Commands: `forward`, `reverse`, `left`, `right`, `stop`, `steer_N`, `headlight_on`, `headlight_off`, `djlight_on`, `djlight_off`, `horn_on`, `horn_off`.

**This is the Android controller only.** The ESP32 firmware must implement this endpoint and map each command to your actual motor driver, steering servo, lights, and horn. Do not assume the car is ready to drive just because the app builds. Test with the wheels lifted and have an adult help check the wiring and power setup.

## Build an APK with GitHub Actions
The included workflow builds a debug APK whenever code is pushed to `main`, and uploads it as an artifact named `DriftCar-debug-apk`.

1. Upload the contents of this project folder to the root of your GitHub repository.
2. Open the repository's **Actions** tab.
3. Open the run named **Build DriftCar APK**.
4. When it succeeds, download the **DriftCar-debug-apk** artifact. The APK inside is `app-debug.apk`.
