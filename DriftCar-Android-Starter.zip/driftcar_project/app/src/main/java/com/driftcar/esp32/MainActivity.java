package com.driftcar.esp32;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private EditText ipInput;
    private TextView status;
    private int lastAngle = -1;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setStatusBarColor(Color.rgb(8,12,20));
        getWindow().setNavigationBarColor(Color.rgb(8,12,20));
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(10),dp(16),dp(10));
        root.setBackgroundColor(Color.rgb(8,12,20));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("DRIFT CAR",22,Color.WHITE,true);
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        ipInput = new EditText(this);
        ipInput.setSingleLine(true); ipInput.setText("192.168.4.1");
        ipInput.setHint("ESP32 IP"); ipInput.setTextColor(Color.WHITE);
        ipInput.setHintTextColor(Color.LTGRAY); ipInput.setTextSize(14);
        ipInput.setInputType(InputType.TYPE_CLASS_PHONE);
        ipInput.setPadding(dp(10),0,dp(10),0); ipInput.setBackground(bg(Color.rgb(30,39,55),10));
        top.addView(ipInput,new LinearLayout.LayoutParams(dp(150),dp(42)));
        root.addView(top);

        status = text("● DISCONNECTED  ·  Join the ESP32 Wi-Fi network",12,Color.rgb(255,190,70),false);
        status.setPadding(0,dp(5),0,dp(8)); root.addView(status);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        body.setGravity(Gravity.CENTER);
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout drive = new LinearLayout(this);
        drive.setOrientation(LinearLayout.VERTICAL); drive.setGravity(Gravity.CENTER);
        body.addView(drive,new LinearLayout.LayoutParams(0,-1,1.1f));
        TextView driveTitle=text("DRIVE",12,Color.GRAY,true); drive.addView(driveTitle);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER);
        drive.addView(row);
        addHold(row,"◀ LEFT","left",Color.rgb(39,72,110),1);
        LinearLayout mid = new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL);
        row.addView(mid);
        addHold(mid,"▲  FORWARD","forward",Color.rgb(0,150,125),0);
        addHold(mid,"▼  REVERSE","reverse",Color.rgb(170,91,36),0);
        addHold(row,"RIGHT ▶","right",Color.rgb(39,72,110),1);
        Button stop=button("■  STOP",Color.rgb(180,48,58),18);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(190),dp(46)); sp.topMargin=dp(8);
        drive.addView(stop,sp); stop.setOnClickListener(v->send("stop"));

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL); side.setGravity(Gravity.CENTER);
        side.setPadding(dp(12),0,0,0);
        body.addView(side,new LinearLayout.LayoutParams(0,-1,0.9f));
        TextView steerTitle=text("STEERING",12,Color.GRAY,true); side.addView(steerTitle);
        SeekBar steering = new SeekBar(this);
        steering.setMax(180); steering.setProgress(90);
        side.addView(steering,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView angle=text("90°  ·  CENTER",12,Color.WHITE,true); side.addView(angle);
        steering.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean user){
                int a=Math.max(0,Math.min(180,p)); angle.setText(a+"°");
                if(user && Math.abs(a-lastAngle)>=3){lastAngle=a;send("steer_"+a);}
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        LinearLayout toggles=new LinearLayout(this); toggles.setGravity(Gravity.CENTER);
        side.addView(toggles);
        addToggle(toggles,"HEADLIGHT","headlight");
        addToggle(toggles,"DJ LIGHT","djlight");
        Button horn=button("HORN",Color.rgb(118,65,170),15);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(48)); hp.topMargin=dp(8);
        side.addView(horn,hp);
        horn.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){send("horn_on");return true;}
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){send("horn_off");return true;}
            return true;
        });
        TextView foot=text("HOLD TO DRIVE  •  RELEASE TO STOP",10,Color.GRAY,true);
        foot.setGravity(Gravity.CENTER); root.addView(foot);
    }

    private void addHold(LinearLayout parent,String label,String command,int color,int vertical) {
        Button b=button(label,color,14);
        LinearLayout.LayoutParams p = vertical==1
            ? new LinearLayout.LayoutParams(dp(92),dp(112))
            : new LinearLayout.LayoutParams(dp(190),dp(48));
        p.setMargins(dp(4),dp(4),dp(4),dp(4)); parent.addView(b,p);
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){send(command);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){send("stop");return true;}
            return true;
        });
    }
    private void addToggle(LinearLayout parent,String label,String key) {
        Switch s=new Switch(this); s.setText(label); s.setTextColor(Color.WHITE); s.setTextSize(11);
        s.setPadding(dp(5),dp(4),dp(5),dp(4)); parent.addView(s);
        s.setOnCheckedChangeListener((b,on)->send(key+(on?"_on":"_off")));
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private Button button(String label,int color,int size){
        Button b=new Button(this);b.setText(label);b.setTextSize(size);b.setTextColor(Color.WHITE);
        b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(bg(color,14));return b;
    }
    private void send(String command){
        final String host=ipInput.getText().toString().trim();
        if(host.isEmpty())return;
        status.setText("● SENDING  ·  "+command.toUpperCase());
        io.execute(()->{
            HttpURLConnection c=null;
            try{
                URL u=new URL("http://"+host+"/cmd?value="+command);
                c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");
                c.setConnectTimeout(700);c.setReadTimeout(700);
                int code=c.getResponseCode();
                runOnUiThread(()->status.setText(code>=200&&code<300
                    ?"● CONNECTED  ·  "+command.toUpperCase()
                    :"● ESP32 ERROR  ·  HTTP "+code));
            }catch(Exception ex){
                runOnUiThread(()->status.setText("● NO RESPONSE  ·  Check Wi-Fi / ESP32 IP"));
            }finally{if(c!=null)c.disconnect();}
        });
    }
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
